package com.example.dietplan.interfaces;

public interface OnClick {

    void click(int position, String type, String otherType, String title, String id, String videoType, String videoLink);

}
