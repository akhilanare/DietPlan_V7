package com.example.dietplan.interfaces;

public interface FavouriteIF {

    void isFavourite(boolean isFavourite, String message);

}
